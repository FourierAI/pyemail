a simple python tool to send email.
