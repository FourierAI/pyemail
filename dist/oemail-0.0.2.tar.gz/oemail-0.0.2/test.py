from oemail import oemail

sender = "939647181@qq.com"
receiver = "zhipengye@nustti.edu.cn"
subject = "Test"
mes = "This is a test email."
auth_code = "vaocvvtxkwcybfbh"

oemail.send_email(sender=sender, receiver=receiver, subject=subject, mes=mes, auth_code=auth_code)